<?php
require_once '../../config/database.php';

try {
    // Create items table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        type ENUM('lost', 'found') NOT NULL,
        location VARCHAR(255),
        user_id INT NOT NULL,
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )");

    // Check if there are any items in the table
    $stmt = $pdo->query("SELECT COUNT(*) FROM items");
    $count = $stmt->fetchColumn();

    if ($count == 0) {
        // Add some sample items
        $sampleItems = [
            ['Lost Phone', 'iPhone 12, black case', 'lost', 'SR Block', 1, 'default.jpg'],
            ['Found Keys', 'Set of 3 keys with blue keychain', 'found', 'C Block', 1, 'default.jpg'],
            ['Lost Wallet', 'Brown leather wallet', 'lost', 'X Lab', 1, 'default.jpg']
        ];

        $stmt = $pdo->prepare("INSERT INTO items (title, description, type, location, user_id, image) VALUES (?, ?, ?, ?, ?, ?)");
        
        foreach ($sampleItems as $item) {
            $stmt->execute($item);
        }

        echo "Items table created and sample data added successfully!";
    } else {
        echo "Items table exists and contains $count items.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 