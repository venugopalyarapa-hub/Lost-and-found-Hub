<?php
$host = 'localhost';
$username = 'root';
$password = 'Mahesh_123$'; // Default for XAMPP

try {
    // First, connect without selecting a database
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Database Connection Check</h2>";
    echo "✅ Successfully connected to MySQL server<br><br>";
    
    // Check if the database exists
    $stmt = $pdo->query("SHOW DATABASES LIKE 'lostfoundhub'");
    $dbExists = $stmt->rowCount() > 0;
    
    if ($dbExists) {
        echo "✅ Database 'lostfoundhub' exists<br>";
        
        // Select the database
        $pdo->exec("USE lostfoundhub");
        
        // Check tables
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "<br>Tables in database:<br>";
        if (count($tables) > 0) {
            echo "<ul>";
            foreach ($tables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
        } else {
            echo "No tables found in the database.";
        }
    } else {
        echo "❌ Database 'lostfoundhub' does not exist<br>";
        echo "You need to create the database first.";
    }
    
} catch (PDOException $e) {
    echo "❌ Connection failed: " . $e->getMessage();
}
?> 