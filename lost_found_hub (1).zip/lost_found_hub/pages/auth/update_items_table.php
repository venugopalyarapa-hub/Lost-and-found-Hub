<?php
session_start();

define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));
define('BASE_URL', 'http://localhost/lost_found_hub');

require_once(ROOT_PATH . '/config/database.php');

try {
    // Check if columns exist
    $stmt = $pdo->query("SHOW COLUMNS FROM items LIKE 'latitude'");
    $latitudeExists = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW COLUMNS FROM items LIKE 'longitude'");
    $longitudeExists = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW COLUMNS FROM items LIKE 'status'");
    $statusExists = $stmt->rowCount() > 0;
    
    // Add columns if they don't exist
    if (!$latitudeExists) {
        $pdo->exec("ALTER TABLE items ADD COLUMN latitude DECIMAL(10, 8) NULL");
    }
    
    if (!$longitudeExists) {
        $pdo->exec("ALTER TABLE items ADD COLUMN longitude DECIMAL(11, 8) NULL");
    }
    
    if (!$statusExists) {
        $pdo->exec("ALTER TABLE items ADD COLUMN status VARCHAR(20) DEFAULT 'active'");
    }
    
    $message = "Items table updated successfully with location coordinates and status field!";
    $messageType = "success";
} catch(PDOException $e) {
    $message = "Error updating items table: " . $e->getMessage();
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Items Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Database Setup</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-<?php echo $messageType; ?>">
                            <?php echo $message; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">Return to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 