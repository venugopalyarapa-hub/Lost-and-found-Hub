<?php
session_start();

define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));
define('BASE_URL', 'http://localhost/lost_found_hub');

require_once(ROOT_PATH . '/config/database.php');

try {
    // Check if read_at column exists
    $stmt = $pdo->query("SHOW COLUMNS FROM notifications LIKE 'read_at'");
    $readAtExists = $stmt->rowCount() > 0;
    
    // Add read_at column if it doesn't exist
    if (!$readAtExists) {
        $pdo->exec("ALTER TABLE notifications ADD COLUMN read_at TIMESTAMP NULL DEFAULT NULL");
        $message = "Notifications table updated successfully with read_at column!";
        $messageType = "success";
    } else {
        $message = "read_at column already exists in the notifications table.";
        $messageType = "info";
    }
} catch(PDOException $e) {
    $message = "Error updating notifications table: " . $e->getMessage();
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Notifications Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Database Setup</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-<?php echo $messageType; ?>">
                            <?php echo $message; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">Return to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 