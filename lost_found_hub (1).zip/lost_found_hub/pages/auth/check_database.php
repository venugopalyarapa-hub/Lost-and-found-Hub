<?php
require_once '../../config/database.php';

try {
    echo "<h2>Database Structure Check</h2>";
    
    // Check if tables exist
    $tables = ['users', 'items', 'conversations', 'messages'];
    
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        $exists = $stmt->rowCount() > 0;
        
        echo "<h3>Table: $table</h3>";
        if ($exists) {
            echo "✅ Table exists<br>";
            
            // Count records
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $stmt->fetchColumn();
            echo "Records: $count<br>";
            
            // Show structure
            $stmt = $pdo->query("DESCRIBE $table");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
            foreach ($columns as $column) {
                echo "<tr>";
                echo "<td>" . $column['Field'] . "</td>";
                echo "<td>" . $column['Type'] . "</td>";
                echo "<td>" . $column['Null'] . "</td>";
                echo "<td>" . $column['Key'] . "</td>";
                echo "<td>" . $column['Default'] . "</td>";
                echo "<td>" . $column['Extra'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "❌ Table does not exist<br>";
        }
        echo "<hr>";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 