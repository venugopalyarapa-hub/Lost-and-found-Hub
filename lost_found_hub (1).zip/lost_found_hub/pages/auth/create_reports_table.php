<?php
session_start();

define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));
define('BASE_URL', 'http://localhost/lost_found_hub');

require_once(ROOT_PATH . '/config/database.php');

try {
    // Check if reports table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'reports'");
    $tableExists = $stmt->rowCount() > 0;

    if (!$tableExists) {
        // Create reports table
        $sql = "CREATE TABLE reports (
            id INT PRIMARY KEY AUTO_INCREMENT,
            item_id INT NOT NULL,
            reporter_id INT NOT NULL,
            reason TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
            FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        
        $conn->exec($sql);
        $message = "Reports table created successfully!";
        $messageType = "success";
    } else {
        $message = "Reports table already exists.";
        $messageType = "info";
    }
} catch(PDOException $e) {
    $message = "Error creating reports table: " . $e->getMessage();
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Reports Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Database Setup</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-<?php echo $messageType; ?>">
                            <?php echo $message; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">Return to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 